# contract-tool-js

## Usage

```
sudo npm install contract-tool-js -g
contract-tool-js init MyContractProject
cd MyContractProject
npm deploy
```
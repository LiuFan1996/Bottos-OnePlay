// 测试链地址: http://120.79.187.5:8689/v1
// test:"http://192.168.52.130:8689/v1"

module.exports = {
    node_config:{
        base_url:"http://120.79.187.5:8689/v1"
    },
    keystore_pwd:'gyhyhck0706'
}

// public_key: 04be15872a2e4d9c9c3b5b78007c1a794ba39cfa601fcbbece4f7b92901bd4e7d8d5b7299a1b42e1e837f9655047e343fa330afb8efb13d5584b5b07f7123686e4
// private_key: 20331e0dfb9fd0c6be6f34d553183466230147916706e5e4ffd561917be50744